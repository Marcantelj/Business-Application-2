﻿namespace Marcantel_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.termInformationGroupBox = new System.Windows.Forms.GroupBox();
            this.yearLabel = new System.Windows.Forms.Label();
            this.springRadioButton = new System.Windows.Forms.RadioButton();
            this.fallRadioButton = new System.Windows.Forms.RadioButton();
            this.yearComboBox = new System.Windows.Forms.ComboBox();
            this.studentInformationGroupBox = new System.Windows.Forms.GroupBox();
            this.studentIDMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.emailTextBox = new System.Windows.Forms.TextBox();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.outOfStateRadioButton = new System.Windows.Forms.RadioButton();
            this.firstNameTextBox = new System.Windows.Forms.TextBox();
            this.inStateRadioButton = new System.Windows.Forms.RadioButton();
            this.residentstatusLabel = new System.Windows.Forms.Label();
            this.emailLabel = new System.Windows.Forms.Label();
            this.studentIDLabel = new System.Windows.Forms.Label();
            this.firstNameLabel = new System.Windows.Forms.Label();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.courseOrderGroupBox = new System.Windows.Forms.GroupBox();
            this.numberOfCoursesLabel = new System.Windows.Forms.Label();
            this.totalPriceLabel = new System.Windows.Forms.Label();
            this.priceLabel = new System.Windows.Forms.Label();
            this.coursesLabel = new System.Windows.Forms.Label();
            this.individualCoursesPriceLabel = new System.Windows.Forms.Label();
            this.selectUpToThreeCourseLabel = new System.Windows.Forms.Label();
            this.beginningSpanishCheckBox = new System.Windows.Forms.CheckBox();
            this.beginningRussianCheckBox = new System.Windows.Forms.CheckBox();
            this.beginningItalianCheckBox = new System.Windows.Forms.CheckBox();
            this.beginningGermanCheckBox = new System.Windows.Forms.CheckBox();
            this.beginningFrenchcheckBox = new System.Windows.Forms.CheckBox();
            this.paymentInformationGroupBox = new System.Windows.Forms.GroupBox();
            this.experationDateLabel = new System.Windows.Forms.Label();
            this.creditCardNumberLabel = new System.Windows.Forms.Label();
            this.creditcardMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.experationDateMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.masterCardRadioButton = new System.Windows.Forms.RadioButton();
            this.visaRadioButton = new System.Windows.Forms.RadioButton();
            this.saveButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.exitToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.clearToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.saveToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.languagePictureBox = new System.Windows.Forms.PictureBox();
            this.termInformationGroupBox.SuspendLayout();
            this.studentInformationGroupBox.SuspendLayout();
            this.courseOrderGroupBox.SuspendLayout();
            this.paymentInformationGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.languagePictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // termInformationGroupBox
            // 
            this.termInformationGroupBox.Controls.Add(this.yearLabel);
            this.termInformationGroupBox.Controls.Add(this.springRadioButton);
            this.termInformationGroupBox.Controls.Add(this.fallRadioButton);
            this.termInformationGroupBox.Controls.Add(this.yearComboBox);
            this.termInformationGroupBox.Location = new System.Drawing.Point(223, 22);
            this.termInformationGroupBox.Name = "termInformationGroupBox";
            this.termInformationGroupBox.Size = new System.Drawing.Size(182, 83);
            this.termInformationGroupBox.TabIndex = 0;
            this.termInformationGroupBox.TabStop = false;
            this.termInformationGroupBox.Text = "Term Information";
            // 
            // yearLabel
            // 
            this.yearLabel.AutoSize = true;
            this.yearLabel.Location = new System.Drawing.Point(38, 47);
            this.yearLabel.Name = "yearLabel";
            this.yearLabel.Size = new System.Drawing.Size(32, 13);
            this.yearLabel.TabIndex = 2;
            this.yearLabel.Text = "Year:";
            // 
            // springRadioButton
            // 
            this.springRadioButton.AutoSize = true;
            this.springRadioButton.Location = new System.Drawing.Point(91, 21);
            this.springRadioButton.Name = "springRadioButton";
            this.springRadioButton.Size = new System.Drawing.Size(55, 17);
            this.springRadioButton.TabIndex = 1;
            this.springRadioButton.Text = "Spring";
            this.springRadioButton.UseVisualStyleBackColor = true;
            this.springRadioButton.CheckedChanged += new System.EventHandler(this.springRadioButton_CheckedChanged);
            // 
            // fallRadioButton
            // 
            this.fallRadioButton.AutoSize = true;
            this.fallRadioButton.Checked = true;
            this.fallRadioButton.Location = new System.Drawing.Point(41, 21);
            this.fallRadioButton.Name = "fallRadioButton";
            this.fallRadioButton.Size = new System.Drawing.Size(44, 17);
            this.fallRadioButton.TabIndex = 0;
            this.fallRadioButton.TabStop = true;
            this.fallRadioButton.Text = " Fall";
            this.fallRadioButton.UseVisualStyleBackColor = true;
            this.fallRadioButton.CheckedChanged += new System.EventHandler(this.fallRadioButton_CheckedChanged);
            // 
            // yearComboBox
            // 
            this.yearComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.yearComboBox.FormattingEnabled = true;
            this.yearComboBox.Items.AddRange(new object[] {
            "2018",
            "2019",
            "2020",
            "2021",
            "2022",
            "2023"});
            this.yearComboBox.Location = new System.Drawing.Point(76, 44);
            this.yearComboBox.Name = "yearComboBox";
            this.yearComboBox.Size = new System.Drawing.Size(70, 21);
            this.yearComboBox.TabIndex = 3;
            // 
            // studentInformationGroupBox
            // 
            this.studentInformationGroupBox.Controls.Add(this.studentIDMaskedTextBox);
            this.studentInformationGroupBox.Controls.Add(this.emailTextBox);
            this.studentInformationGroupBox.Controls.Add(this.lastNameTextBox);
            this.studentInformationGroupBox.Controls.Add(this.outOfStateRadioButton);
            this.studentInformationGroupBox.Controls.Add(this.firstNameTextBox);
            this.studentInformationGroupBox.Controls.Add(this.inStateRadioButton);
            this.studentInformationGroupBox.Controls.Add(this.residentstatusLabel);
            this.studentInformationGroupBox.Controls.Add(this.emailLabel);
            this.studentInformationGroupBox.Controls.Add(this.studentIDLabel);
            this.studentInformationGroupBox.Controls.Add(this.firstNameLabel);
            this.studentInformationGroupBox.Controls.Add(this.lastNameLabel);
            this.studentInformationGroupBox.Location = new System.Drawing.Point(12, 121);
            this.studentInformationGroupBox.Name = "studentInformationGroupBox";
            this.studentInformationGroupBox.Size = new System.Drawing.Size(393, 121);
            this.studentInformationGroupBox.TabIndex = 1;
            this.studentInformationGroupBox.TabStop = false;
            this.studentInformationGroupBox.Text = "Student Information";
            // 
            // studentIDMaskedTextBox
            // 
            this.studentIDMaskedTextBox.Location = new System.Drawing.Point(272, 57);
            this.studentIDMaskedTextBox.Mask = "000-00-0000";
            this.studentIDMaskedTextBox.Name = "studentIDMaskedTextBox";
            this.studentIDMaskedTextBox.Size = new System.Drawing.Size(65, 20);
            this.studentIDMaskedTextBox.TabIndex = 7;
            this.studentIDMaskedTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // emailTextBox
            // 
            this.emailTextBox.Location = new System.Drawing.Point(273, 19);
            this.emailTextBox.Name = "emailTextBox";
            this.emailTextBox.Size = new System.Drawing.Size(108, 20);
            this.emailTextBox.TabIndex = 5;
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(76, 57);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(108, 20);
            this.lastNameTextBox.TabIndex = 3;
            // 
            // outOfStateRadioButton
            // 
            this.outOfStateRadioButton.AutoSize = true;
            this.outOfStateRadioButton.Location = new System.Drawing.Point(234, 98);
            this.outOfStateRadioButton.Name = "outOfStateRadioButton";
            this.outOfStateRadioButton.Size = new System.Drawing.Size(84, 17);
            this.outOfStateRadioButton.TabIndex = 10;
            this.outOfStateRadioButton.Text = "Out-Of-State";
            this.outOfStateRadioButton.UseVisualStyleBackColor = true;
            this.outOfStateRadioButton.CheckedChanged += new System.EventHandler(this.outofstateRadioButton_CheckedChanged);
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.Location = new System.Drawing.Point(76, 19);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(108, 20);
            this.firstNameTextBox.TabIndex = 1;
            // 
            // inStateRadioButton
            // 
            this.inStateRadioButton.AutoSize = true;
            this.inStateRadioButton.Checked = true;
            this.inStateRadioButton.Location = new System.Drawing.Point(166, 98);
            this.inStateRadioButton.Name = "inStateRadioButton";
            this.inStateRadioButton.Size = new System.Drawing.Size(62, 17);
            this.inStateRadioButton.TabIndex = 9;
            this.inStateRadioButton.TabStop = true;
            this.inStateRadioButton.Text = "In-State";
            this.inStateRadioButton.UseVisualStyleBackColor = true;
            this.inStateRadioButton.CheckedChanged += new System.EventHandler(this.instateRadioButton_CheckedChanged);
            // 
            // residentstatusLabel
            // 
            this.residentstatusLabel.AutoSize = true;
            this.residentstatusLabel.Location = new System.Drawing.Point(72, 100);
            this.residentstatusLabel.Name = "residentstatusLabel";
            this.residentstatusLabel.Size = new System.Drawing.Size(88, 13);
            this.residentstatusLabel.TabIndex = 8;
            this.residentstatusLabel.Text = "Resident Status: ";
            // 
            // emailLabel
            // 
            this.emailLabel.AutoSize = true;
            this.emailLabel.Location = new System.Drawing.Point(190, 22);
            this.emailLabel.Name = "emailLabel";
            this.emailLabel.Size = new System.Drawing.Size(76, 13);
            this.emailLabel.TabIndex = 4;
            this.emailLabel.Text = "Email Address:";
            // 
            // studentIDLabel
            // 
            this.studentIDLabel.AutoSize = true;
            this.studentIDLabel.Location = new System.Drawing.Point(207, 60);
            this.studentIDLabel.Name = "studentIDLabel";
            this.studentIDLabel.Size = new System.Drawing.Size(61, 13);
            this.studentIDLabel.TabIndex = 6;
            this.studentIDLabel.Text = "Student ID:";
            // 
            // firstNameLabel
            // 
            this.firstNameLabel.AutoSize = true;
            this.firstNameLabel.Location = new System.Drawing.Point(10, 22);
            this.firstNameLabel.Name = "firstNameLabel";
            this.firstNameLabel.Size = new System.Drawing.Size(60, 13);
            this.firstNameLabel.TabIndex = 0;
            this.firstNameLabel.Text = "First Name:";
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(9, 60);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(61, 13);
            this.lastNameLabel.TabIndex = 2;
            this.lastNameLabel.Text = "Last Name:";
            // 
            // courseOrderGroupBox
            // 
            this.courseOrderGroupBox.Controls.Add(this.numberOfCoursesLabel);
            this.courseOrderGroupBox.Controls.Add(this.totalPriceLabel);
            this.courseOrderGroupBox.Controls.Add(this.priceLabel);
            this.courseOrderGroupBox.Controls.Add(this.coursesLabel);
            this.courseOrderGroupBox.Controls.Add(this.individualCoursesPriceLabel);
            this.courseOrderGroupBox.Controls.Add(this.selectUpToThreeCourseLabel);
            this.courseOrderGroupBox.Controls.Add(this.beginningSpanishCheckBox);
            this.courseOrderGroupBox.Controls.Add(this.beginningRussianCheckBox);
            this.courseOrderGroupBox.Controls.Add(this.beginningItalianCheckBox);
            this.courseOrderGroupBox.Controls.Add(this.beginningGermanCheckBox);
            this.courseOrderGroupBox.Controls.Add(this.beginningFrenchcheckBox);
            this.courseOrderGroupBox.Location = new System.Drawing.Point(12, 248);
            this.courseOrderGroupBox.Name = "courseOrderGroupBox";
            this.courseOrderGroupBox.Size = new System.Drawing.Size(393, 162);
            this.courseOrderGroupBox.TabIndex = 2;
            this.courseOrderGroupBox.TabStop = false;
            this.courseOrderGroupBox.Text = "Course Order Information";
            // 
            // numberOfCoursesLabel
            // 
            this.numberOfCoursesLabel.AutoSize = true;
            this.numberOfCoursesLabel.Location = new System.Drawing.Point(313, 114);
            this.numberOfCoursesLabel.Name = "numberOfCoursesLabel";
            this.numberOfCoursesLabel.Size = new System.Drawing.Size(13, 13);
            this.numberOfCoursesLabel.TabIndex = 8;
            this.numberOfCoursesLabel.Text = "0";
            // 
            // totalPriceLabel
            // 
            this.totalPriceLabel.AutoSize = true;
            this.totalPriceLabel.Location = new System.Drawing.Point(270, 136);
            this.totalPriceLabel.Name = "totalPriceLabel";
            this.totalPriceLabel.Size = new System.Drawing.Size(34, 13);
            this.totalPriceLabel.TabIndex = 10;
            this.totalPriceLabel.Text = "$0.00";
            // 
            // priceLabel
            // 
            this.priceLabel.AutoSize = true;
            this.priceLabel.Location = new System.Drawing.Point(205, 136);
            this.priceLabel.Name = "priceLabel";
            this.priceLabel.Size = new System.Drawing.Size(61, 13);
            this.priceLabel.TabIndex = 9;
            this.priceLabel.Text = "Total Price:";
            // 
            // coursesLabel
            // 
            this.coursesLabel.AutoSize = true;
            this.coursesLabel.Location = new System.Drawing.Point(207, 114);
            this.coursesLabel.Name = "coursesLabel";
            this.coursesLabel.Size = new System.Drawing.Size(100, 13);
            this.coursesLabel.TabIndex = 7;
            this.coursesLabel.Text = "Number of Courses:";
            // 
            // individualCoursesPriceLabel
            // 
            this.individualCoursesPriceLabel.AutoSize = true;
            this.individualCoursesPriceLabel.Location = new System.Drawing.Point(51, 123);
            this.individualCoursesPriceLabel.Name = "individualCoursesPriceLabel";
            this.individualCoursesPriceLabel.Size = new System.Drawing.Size(129, 13);
            this.individualCoursesPriceLabel.TabIndex = 6;
            this.individualCoursesPriceLabel.Text = "Courses are: $49.00 each";
            // 
            // selectUpToThreeCourseLabel
            // 
            this.selectUpToThreeCourseLabel.AutoSize = true;
            this.selectUpToThreeCourseLabel.Location = new System.Drawing.Point(63, 20);
            this.selectUpToThreeCourseLabel.Name = "selectUpToThreeCourseLabel";
            this.selectUpToThreeCourseLabel.Size = new System.Drawing.Size(117, 13);
            this.selectUpToThreeCourseLabel.TabIndex = 0;
            this.selectUpToThreeCourseLabel.Text = "Select up to 3 Courses.";
            // 
            // beginningSpanishCheckBox
            // 
            this.beginningSpanishCheckBox.AutoSize = true;
            this.beginningSpanishCheckBox.Location = new System.Drawing.Point(208, 85);
            this.beginningSpanishCheckBox.Name = "beginningSpanishCheckBox";
            this.beginningSpanishCheckBox.Size = new System.Drawing.Size(114, 17);
            this.beginningSpanishCheckBox.TabIndex = 5;
            this.beginningSpanishCheckBox.Text = "Beginning Spanish";
            this.beginningSpanishCheckBox.UseVisualStyleBackColor = true;
            this.beginningSpanishCheckBox.CheckedChanged += new System.EventHandler(this.beginningFrenchcheckBox_CheckedChanged);
            // 
            // beginningRussianCheckBox
            // 
            this.beginningRussianCheckBox.AutoSize = true;
            this.beginningRussianCheckBox.Location = new System.Drawing.Point(208, 53);
            this.beginningRussianCheckBox.Name = "beginningRussianCheckBox";
            this.beginningRussianCheckBox.Size = new System.Drawing.Size(114, 17);
            this.beginningRussianCheckBox.TabIndex = 3;
            this.beginningRussianCheckBox.Text = "Beginning Russian";
            this.beginningRussianCheckBox.UseVisualStyleBackColor = true;
            this.beginningRussianCheckBox.CheckedChanged += new System.EventHandler(this.beginningFrenchcheckBox_CheckedChanged);
            // 
            // beginningItalianCheckBox
            // 
            this.beginningItalianCheckBox.AutoSize = true;
            this.beginningItalianCheckBox.Location = new System.Drawing.Point(208, 19);
            this.beginningItalianCheckBox.Name = "beginningItalianCheckBox";
            this.beginningItalianCheckBox.Size = new System.Drawing.Size(104, 17);
            this.beginningItalianCheckBox.TabIndex = 1;
            this.beginningItalianCheckBox.Text = "Beginning Italian";
            this.beginningItalianCheckBox.UseVisualStyleBackColor = true;
            this.beginningItalianCheckBox.CheckedChanged += new System.EventHandler(this.beginningFrenchcheckBox_CheckedChanged);
            // 
            // beginningGermanCheckBox
            // 
            this.beginningGermanCheckBox.AutoSize = true;
            this.beginningGermanCheckBox.Location = new System.Drawing.Point(71, 85);
            this.beginningGermanCheckBox.Name = "beginningGermanCheckBox";
            this.beginningGermanCheckBox.Size = new System.Drawing.Size(113, 17);
            this.beginningGermanCheckBox.TabIndex = 4;
            this.beginningGermanCheckBox.Text = "Beginning German";
            this.beginningGermanCheckBox.UseVisualStyleBackColor = true;
            this.beginningGermanCheckBox.CheckedChanged += new System.EventHandler(this.beginningFrenchcheckBox_CheckedChanged);
            // 
            // beginningFrenchcheckBox
            // 
            this.beginningFrenchcheckBox.AutoSize = true;
            this.beginningFrenchcheckBox.Location = new System.Drawing.Point(71, 53);
            this.beginningFrenchcheckBox.Name = "beginningFrenchcheckBox";
            this.beginningFrenchcheckBox.Size = new System.Drawing.Size(109, 17);
            this.beginningFrenchcheckBox.TabIndex = 2;
            this.beginningFrenchcheckBox.Text = "Beginning French";
            this.beginningFrenchcheckBox.UseVisualStyleBackColor = true;
            this.beginningFrenchcheckBox.CheckedChanged += new System.EventHandler(this.beginningFrenchcheckBox_CheckedChanged);
            // 
            // paymentInformationGroupBox
            // 
            this.paymentInformationGroupBox.Controls.Add(this.experationDateLabel);
            this.paymentInformationGroupBox.Controls.Add(this.creditCardNumberLabel);
            this.paymentInformationGroupBox.Controls.Add(this.creditcardMaskedTextBox);
            this.paymentInformationGroupBox.Controls.Add(this.experationDateMaskedTextBox);
            this.paymentInformationGroupBox.Controls.Add(this.masterCardRadioButton);
            this.paymentInformationGroupBox.Controls.Add(this.visaRadioButton);
            this.paymentInformationGroupBox.Location = new System.Drawing.Point(12, 416);
            this.paymentInformationGroupBox.Name = "paymentInformationGroupBox";
            this.paymentInformationGroupBox.Size = new System.Drawing.Size(393, 99);
            this.paymentInformationGroupBox.TabIndex = 4;
            this.paymentInformationGroupBox.TabStop = false;
            this.paymentInformationGroupBox.Text = "Payment Information";
            // 
            // experationDateLabel
            // 
            this.experationDateLabel.AutoSize = true;
            this.experationDateLabel.Location = new System.Drawing.Point(180, 70);
            this.experationDateLabel.Name = "experationDateLabel";
            this.experationDateLabel.Size = new System.Drawing.Size(86, 13);
            this.experationDateLabel.TabIndex = 4;
            this.experationDateLabel.Text = "Experation Date:";
            // 
            // creditCardNumberLabel
            // 
            this.creditCardNumberLabel.AutoSize = true;
            this.creditCardNumberLabel.Location = new System.Drawing.Point(164, 30);
            this.creditCardNumberLabel.Name = "creditCardNumberLabel";
            this.creditCardNumberLabel.Size = new System.Drawing.Size(102, 13);
            this.creditCardNumberLabel.TabIndex = 2;
            this.creditCardNumberLabel.Text = "Credit Card Number:";
            // 
            // creditcardMaskedTextBox
            // 
            this.creditcardMaskedTextBox.Location = new System.Drawing.Point(272, 27);
            this.creditcardMaskedTextBox.Mask = " 0000-0000-0000-0000";
            this.creditcardMaskedTextBox.Name = "creditcardMaskedTextBox";
            this.creditcardMaskedTextBox.Size = new System.Drawing.Size(114, 20);
            this.creditcardMaskedTextBox.TabIndex = 3;
            this.creditcardMaskedTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // experationDateMaskedTextBox
            // 
            this.experationDateMaskedTextBox.Location = new System.Drawing.Point(272, 66);
            this.experationDateMaskedTextBox.Mask = " 00/00/0000";
            this.experationDateMaskedTextBox.Name = "experationDateMaskedTextBox";
            this.experationDateMaskedTextBox.Size = new System.Drawing.Size(65, 20);
            this.experationDateMaskedTextBox.TabIndex = 5;
            this.experationDateMaskedTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.experationDateMaskedTextBox.ValidatingType = typeof(System.DateTime);
            // 
            // masterCardRadioButton
            // 
            this.masterCardRadioButton.AutoSize = true;
            this.masterCardRadioButton.Checked = true;
            this.masterCardRadioButton.Location = new System.Drawing.Point(34, 28);
            this.masterCardRadioButton.Name = "masterCardRadioButton";
            this.masterCardRadioButton.Size = new System.Drawing.Size(79, 17);
            this.masterCardRadioButton.TabIndex = 0;
            this.masterCardRadioButton.TabStop = true;
            this.masterCardRadioButton.Text = "MasterCard";
            this.masterCardRadioButton.UseVisualStyleBackColor = true;
            this.masterCardRadioButton.CheckedChanged += new System.EventHandler(this.masterCardRadioButton_CheckedChanged);
            // 
            // visaRadioButton
            // 
            this.visaRadioButton.AutoSize = true;
            this.visaRadioButton.Location = new System.Drawing.Point(34, 66);
            this.visaRadioButton.Name = "visaRadioButton";
            this.visaRadioButton.Size = new System.Drawing.Size(45, 17);
            this.visaRadioButton.TabIndex = 1;
            this.visaRadioButton.Text = "Visa";
            this.visaRadioButton.UseVisualStyleBackColor = true;
            this.visaRadioButton.CheckedChanged += new System.EventHandler(this.visaRadioButton_CheckedChanged);
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(46, 533);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(75, 23);
            this.saveButton.TabIndex = 5;
            this.saveButton.Text = "&Save";
            this.saveToolTip.SetToolTip(this.saveButton, "This button allows you to save your current data when pressed.\r\n");
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(170, 533);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 5;
            this.clearButton.Text = "&Clear";
            this.clearToolTip.SetToolTip(this.clearButton, "This button clears all the data inside this application. ");
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(294, 533);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 6;
            this.exitButton.Text = "E&xit";
            this.exitToolTip.SetToolTip(this.exitButton, "This button exits out of application when pressed. ");
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // exitToolTip
            // 
            this.exitToolTip.Tag = "";
            this.exitToolTip.ToolTipTitle = "Exit Button ToolTip";
            // 
            // clearToolTip
            // 
            this.clearToolTip.Tag = "";
            this.clearToolTip.ToolTipTitle = "Clear Button ToolTip";
            // 
            // saveToolTip
            // 
            this.saveToolTip.Tag = "";
            this.saveToolTip.ToolTipTitle = "Save Button ToolTip";
            // 
            // languagePictureBox
            // 
            this.languagePictureBox.Image = global::Marcantel_2.Properties.Resources.Languages;
            this.languagePictureBox.Location = new System.Drawing.Point(12, 14);
            this.languagePictureBox.Name = "languagePictureBox";
            this.languagePictureBox.Size = new System.Drawing.Size(205, 91);
            this.languagePictureBox.TabIndex = 0;
            this.languagePictureBox.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(423, 571);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.courseOrderGroupBox);
            this.Controls.Add(this.studentInformationGroupBox);
            this.Controls.Add(this.paymentInformationGroupBox);
            this.Controls.Add(this.termInformationGroupBox);
            this.Controls.Add(this.languagePictureBox);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Language Arts Institute";
            this.termInformationGroupBox.ResumeLayout(false);
            this.termInformationGroupBox.PerformLayout();
            this.studentInformationGroupBox.ResumeLayout(false);
            this.studentInformationGroupBox.PerformLayout();
            this.courseOrderGroupBox.ResumeLayout(false);
            this.courseOrderGroupBox.PerformLayout();
            this.paymentInformationGroupBox.ResumeLayout(false);
            this.paymentInformationGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.languagePictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox languagePictureBox;
        private System.Windows.Forms.GroupBox termInformationGroupBox;
        private System.Windows.Forms.Label yearLabel;
        private System.Windows.Forms.RadioButton springRadioButton;
        private System.Windows.Forms.RadioButton fallRadioButton;
        private System.Windows.Forms.ComboBox yearComboBox;
        private System.Windows.Forms.GroupBox studentInformationGroupBox;
        private System.Windows.Forms.RadioButton outOfStateRadioButton;
        private System.Windows.Forms.RadioButton inStateRadioButton;
        private System.Windows.Forms.Label residentstatusLabel;
        private System.Windows.Forms.Label emailLabel;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.Label firstNameLabel;
        private System.Windows.Forms.Label studentIDLabel;
        private System.Windows.Forms.GroupBox courseOrderGroupBox;
        private System.Windows.Forms.GroupBox paymentInformationGroupBox;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.TextBox firstNameTextBox;
        private System.Windows.Forms.TextBox emailTextBox;
        private System.Windows.Forms.MaskedTextBox studentIDMaskedTextBox;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.CheckBox beginningSpanishCheckBox;
        private System.Windows.Forms.CheckBox beginningRussianCheckBox;
        private System.Windows.Forms.CheckBox beginningItalianCheckBox;
        private System.Windows.Forms.CheckBox beginningGermanCheckBox;
        private System.Windows.Forms.CheckBox beginningFrenchcheckBox;
        private System.Windows.Forms.Label selectUpToThreeCourseLabel;
        private System.Windows.Forms.MaskedTextBox creditcardMaskedTextBox;
        private System.Windows.Forms.MaskedTextBox experationDateMaskedTextBox;
        private System.Windows.Forms.RadioButton masterCardRadioButton;
        private System.Windows.Forms.RadioButton visaRadioButton;
        private System.Windows.Forms.Label priceLabel;
        private System.Windows.Forms.Label coursesLabel;
        private System.Windows.Forms.Label individualCoursesPriceLabel;
        private System.Windows.Forms.Label experationDateLabel;
        private System.Windows.Forms.Label creditCardNumberLabel;
        private System.Windows.Forms.ToolTip exitToolTip;
        private System.Windows.Forms.ToolTip clearToolTip;
        private System.Windows.Forms.ToolTip saveToolTip;
        private System.Windows.Forms.Label numberOfCoursesLabel;
        private System.Windows.Forms.Label totalPriceLabel;
    }
}

