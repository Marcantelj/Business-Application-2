﻿// Programmer: Jonathan Marcantel
// Project: Marcantel_2
// Due Date: 09/29/2018
// Description: Individual Assignment #2 
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Marcantel_2
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }
        string fallOrSpringString;
        string yearsComboBoxString;
        string residentsString;
        string creditCardString;
        private void beginningFrenchcheckBox_CheckedChanged(object sender, EventArgs e)
        {
            // Setting focus to the first option.
            fallRadioButton.Focus();
            try
            {
                // Declaired local constant decimals for in and out of state prices. 
                const decimal IN_STATE = 49.00m; // in-state price for each course.
                const decimal OUT_OF_STATE = 99.00m; // out-of-state price for each course.

                // Decalring local int and decimal values.
                int totalCourses = 0; //  Counts the number of selected courses. The max amount is three.
                decimal totalPrice = 0m; // total price of totalCourses * in-state or out-of-state constants. 
                
                // This is a counter for the number of totalCourses.
                // This will be used to calculate the total price when it is multiplied by the instate or outofstate price * totalCourses.  
                if (beginningFrenchcheckBox.Checked)
                {
                    totalCourses = +1;
                }
                if (beginningGermanCheckBox.Checked)
                {
                    totalCourses += 1;
                }
                if (beginningItalianCheckBox.Checked)
                {
                    totalCourses += 1;
                }
                if (beginningRussianCheckBox.Checked)
                {
                    totalCourses += 1;
                }
                if (beginningSpanishCheckBox.Checked)
                {
                    totalCourses += 1;
                }


                // Updated display value of form. 
                numberOfCoursesLabel.Text = totalCourses.ToString();

                if (inStateRadioButton.Checked)
                {
                    totalPrice = (IN_STATE * totalCourses);
                }
                if (outOfStateRadioButton.Checked)
                {
                    totalPrice = (OUT_OF_STATE * totalCourses);
                }

                totalPriceLabel.Text = totalPrice.ToString("c");

                // If you put more than three checked boxes than this code is executed.
                // This code clears all check boxes and sends you an error message. 
                if (totalCourses > 3)
                {
                    MessageBox.Show("You have selected more than three corses. Please try again and this time select three or less courses.");
                    (beginningFrenchcheckBox.Checked) = false;
                    (beginningGermanCheckBox.Checked) = false;
                    (beginningItalianCheckBox.Checked) = false;
                    (beginningRussianCheckBox.Checked) = false;
                    (beginningSpanishCheckBox.Checked) = false;
                    totalPriceLabel.Text = "$0.00";


                }
            }
            catch (Exception)
            {

            }
        }
        private void saveButton_Click(object sender, EventArgs e)
        {
            // These one if-statement that let the user save the entered data.
            // When the number of courses is = "0", "4", "5".
            int numberofcourses;
            
            if (int.TryParse(numberOfCoursesLabel.Text, out numberofcourses))
            {
                if (numberofcourses >= 1 && numberofcourses <= 3)
                {
                    yearsComboBoxString = (yearComboBox.Items.ToString());
                    yearsComboBoxString = (yearComboBox.Items.ToString());
                    // Message Box that shows all entered Data. 
                    MessageBox.Show("Term selected and the year: " + fallOrSpringString + " " + yearComboBox.Text + "\n" + "StudentID: " + this.studentIDMaskedTextBox.Text + "\n" + "Student Name: " + this.firstNameTextBox.Text + " " + this.lastNameTextBox.Text +
                        "\n" + "Email Address: " + this.emailTextBox.Text + "\n" + "Resident Status: " + residentsString + "\n" + "Total Courses Purchased: " + this.numberOfCoursesLabel.Text + "\n" +
                        "Total Price Per Course: " + this.individualCoursesPriceLabel.Text + "\n" + "Total Order Price: " + this.totalPriceLabel.Text + "\n" + "Credit Card Type: " + creditCardString + "\n" + "This Credit Card Number " + this.creditcardMaskedTextBox.Text +
                        "\n" + "Card Experationd Date: " + this.experationDateMaskedTextBox.Text);

                }
                // These if-statement that does not let the user save the entered data. 
                // When the number of courses is = "0", "4", "
               
                else if (int.TryParse(numberOfCoursesLabel.Text, out numberofcourses))
                {
                    // if-state to see if the number is true so that this code can exicute. 
                    // when it exicutes it shows a message with a error and exclamation. 
                    if (numberofcourses == 0 || numberofcourses == 4 || numberofcourses == 5)
                        MessageBox.Show("The course order must contain at least one but no more than three courses.", "Error With Saved",
                            MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }


            }
        }
            // Declared String when button is checked for saved button messagebox.
        private void fallRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            fallOrSpringString = " Fall";
        }
        // Declared String when button is checked for saved button messagebox.
        private void springRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            fallOrSpringString = "Spring";
        }
        // Declared String when button is checked for saved button messagebox.
        private void instateRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            residentsString = "In-State";
            const decimal IN_STATE = 49.00m;
            individualCoursesPriceLabel.Text = "Courses are " + IN_STATE.ToString("c") + " each";
        }
        // Declared String when button is checked for saved button messagebox.
        private void outofstateRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            residentsString = "Out-Of-State";
            const decimal OUT_OF_STATE = 99.00m;
            individualCoursesPriceLabel.Text = "Courses are " + OUT_OF_STATE.ToString("c") + " each";
        }
        // Declared String when button is checked for saved button messagebox.
        private void masterCardRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            creditCardString = "Master Card";
        }
        // Declared String when button is checked for saved button messagebox.
        private void visaRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            creditCardString = "Visa";
        }
        // Clears and resets all data even saved data for saved button messagebox. 
        private void clearButton_Click(object sender, EventArgs e)
        {
            fallRadioButton.Checked = true;
            springRadioButton.Checked = false;
            yearComboBox.SelectedIndex = -1;
            firstNameTextBox.Text = "";
            lastNameTextBox.Text = "";
            emailTextBox.Text = "";
            studentIDMaskedTextBox.Text = "";
            inStateRadioButton.Checked = true;
            outOfStateRadioButton.Checked = false;
            beginningFrenchcheckBox.Checked = false;
            beginningGermanCheckBox.Checked = false;
            beginningItalianCheckBox.Checked = false;
            beginningRussianCheckBox.Checked = false;
            beginningSpanishCheckBox.Checked = false;
            numberOfCoursesLabel.Text = "";
            totalPriceLabel.Text = "";
            masterCardRadioButton.Checked = true;
            visaRadioButton.Checked = false;
            creditcardMaskedTextBox.Text = "";
            experationDateMaskedTextBox.Text = "";

            // Send focus to first radio button. 
            fallRadioButton.Focus();
        }


        // Exit Button it closes application. 
        private void exitButton_Click(object sender, EventArgs e)
        {
            // This shows a message if you want to close the application. You choose yes or no. 
            // The if-statement is an exicutible when you hit yes closing the application. 
            {   
                DialogResult selection;
                selection = MessageBox.Show("Are you sure you want to quit?","Confirmation" , MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (selection == DialogResult.Yes)
                {
                    this.Close();
                }
            }
        }
    }
}


 
    


